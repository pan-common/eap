CREATE VIEW V_INDEX_ATTRIBUTES AS select a.zbdm,a.zbshxdm,a.dw,a.sjgs,a.sjldbs,a.yxsj,b.zbshxmc,b.bs,b.zbshxbm from td_index_attribute_map a,td_index_attribute b where a.zbshxdm = b.zbshxdm



/
