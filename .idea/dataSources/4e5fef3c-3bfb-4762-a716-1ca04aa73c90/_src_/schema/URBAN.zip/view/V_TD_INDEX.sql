CREATE VIEW V_TD_INDEX AS select a."ZBDM",a."ZBZTDM",a."ZBFLDM",a."ZBMC",a."JLDW",a."ZBSM",a."SJK",a."SJB",a."SJBHZ_N",a."SJBHZ_J",a."SJBHZ_Y",a."KSSJ",a."ZZSJ",a."ZBMJ",a."SJV",a."SJLY",a."SJLYMC",a."ZBZTMC",a."ZBFLMC",a."ZBSJDM",b.zbflmc as zbsjdm_flmc from v_td_index1 a,td_index_class b where a.zbsjdm=b.zbfldm



/
