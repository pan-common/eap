CREATE VIEW V_T_CS_SJ_SZTJ_M AS select t."ZBDM",t."SJDM",t."QUYDM",t."BYZ",t."YZZL",t."SJBB",t."GXSJ",quydm.quymc,sjdm.sjmc from T_CS_SJ_SZTJ_M t,td_time sjdm,td_district quydm where sjdm.sjdm=t.sjdm and quydm.quydm=t.quydm



/
