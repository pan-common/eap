CREATE VIEW V_T_WM_SJ_GJZZ AS select t."ZBDM",t."GJDM",t."SJDM",t."BYZ",t."BYLJ",t."LJZZL",t."SJBB",t."GXSJ",sjdm.sjmc,gjdm.gjmc from T_WM_SJ_GJZZ t,td_time sjdm,td_country gjdm where t.gjdm=gjdm.gjdm and sjdm.sjdm=t.sjdm



/
