CREATE VIEW VIEW_ZBJF AS select zb.sjid,            ----账本id
       zb.zbbh,            ----账本编号
       xm.xmmc,            ----项目名称
       xm.bmmc,            ----部门名称
       xm.gllx,            ----管理类型：横管/纵管
       xm.xmly,            ----项目来源1
       xm.xmly2,           ----项目来源2
       ht.htje,            ----合同额
       ht.qssj,            ----合同起时间
       ht.jssj,            ----合同止时间
       zb.zt,              ----账本状态：未完成/已完成
       F_KMJY(zb.sjid, 'ZLGL_JFGL_JFKM_JJFY_GLF') glf,              ---管理费
       F_KMJY(zb.sjid, 'ZLGL_JFGL_JFKM_JJFY_JXZC') jxzc,            ---绩效支出
       F_KMJY(zb.sjid, 'ZLGL_JFGL_JFKM_JJFY_GLF')+F_KMJY(zb.sjid, 'ZLGL_JFGL_JFKM_JJFY_JXZC') jjfy,   ----间接费用
       F_KMJY(zb.sjid, 'ZLGL_JFGL_JFKM_ZJFY_SBF') sbf,                ---设备费
       F_KMJY(zb.sjid, 'ZLGL_JFGL_JFKM_ZJFY_CLF') clf,                ---材料费
       F_KMJY(zb.sjid, 'ZLGL_JFGL_JFKM_ZJFY_CSHYSYJGF') CSHYSYJGF,    ---测试化验实验加工费
       F_KMJY(zb.sjid, 'ZLGL_JFGL_JFKM_ZJFY_RLDLF') rldlf,            ---燃料动力费
       F_KMJY(zb.sjid, 'ZLGL_JFGL_JFKM_ZJFY_CHLF') chlf,              ---差旅费
       F_KMJY(zb.sjid, 'ZLGL_JFGL_JFKM_ZJFY_HYF') hyf,                ---会议费
       F_KMJY(zb.sjid, 'ZLGL_JFGL_JFKM_ZJFY_GJHZYJLF') GJHZYJLF,    ---国际合作与交流费
       F_KMJY(zb.sjid, 'ZLGL_JFGL_JFKM_ZJFY_CBF') cbf,              ---出版费
       F_KMJY(zb.sjid, 'ZLGL_JFGL_JFKM_ZJFY_LWF') lwf,              ---劳务费
       F_KMJY(zb.sjid, 'ZLGL_JFGL_JFKM_ZJFY_ZJZXF') ZJZXF,          ---专家咨询费
       F_KMJY(zb.sjid, 'ZLGL_JFGL_JFKM_ZJFY_QTZC') qtzc,            ---其他支出
       F_ZCZJ(ZB.SJID) zczj,                                        ----支出小计
       F_DKSJ(ZB.SJID,1) dksj1,                                   ----第一次到款时间
       F_DKJE(ZB.SJID,1) dkje1,                                   ----第一次到款金额
       F_DKSJ(ZB.SJID,2) dksj2,                                   ----第二次到款时间
       F_DKJE(ZB.SJID,2) dkje2,                                   ----第二次到款金额
       F_DKSJ(ZB.SJID,3) dksj3,                                   ----第三次到款时间
       F_DKJE(ZB.SJID,3) dkje3,                                   ----第三次到款金额
       F_DKSJ(ZB.SJID,4) dksj4,                                   ----第四次到款时间
       F_DKJE(ZB.SJID,4) dkje4,                                   ----第四次到款金额
       F_DKSJ(ZB.SJID,5) dksj5,                                   ----第五次到款时间
       F_DKJE(ZB.SJID,5) dkje5,                                   ----第五次到款金额
       F_WBJE(ZB.SJID,'一级外拨' ) wbje1,                         ----一级外拨金额总
       F_WBJE(ZB.SJID,'二级外拨' ) wbje2                         ----二级外拨金额总
  from t_zlgl_xmzb_jcxx zb
  left join t_zlgl_htgl_jcxx ht
    on zb.htid = ht.sjid
  left join t_zlgl_xmgl_jcxx xm
    on zb.xmid = xm.sjid


/
