CREATE VIEW V_FUND_DETAIL AS select zbid,
       '拨入' "BRZC",                      -- 拨入/支出
       JFKM1,                               -- 经费科目1
       JFKM2,                               --经费科目2
       JFKM3,                               --经费科目3
       JFKM4,                               --经费科目4
       JFKM5,                               --经费科目5
       '' JFLB,                             --经费类别
       brje "MONEY",                        --金额
       DJSJ "DATE",                         --操作时间
       '-' "PERSON",                        --报销人
       BZ "MARK",                           --说明
       djrid,                               --登记人id
       '' HDRID                             --核定人iD
  from t_zlgl_jfgl_jfbr
union all
select zbid,
       '支出' "BRZC",
       JFKM1,
       JFKM2,
       JFKM3,
       JFKM4,
       JFKM5,
       JFLB,
       decode(wblx, '非外拨', hdje, wbje) "MONEY",
       DJSJ "DATE",
       syr "PERSON",
       '出差'||CCTS||'天' "MARK",
       djrid,
       HDRID
  from t_zlgl_jfgl_jfzc
 where zt = '已核定'


/
