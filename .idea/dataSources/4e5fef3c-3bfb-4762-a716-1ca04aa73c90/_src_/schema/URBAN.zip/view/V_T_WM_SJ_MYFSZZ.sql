CREATE VIEW V_T_WM_SJ_MYFSZZ AS select t."ZBDM",t."QUYDM",t."JJDJLXDM",t."DWMYMYFSDM",t."SJDM",t."BYZ",t."YZZL",t."BYLJ",t."LJZZL",t."SJBB",t."GXSJ",sjdm.sjmc,dwmymyfsdm.dwmymyfsmc,quydm.quymc,jjdjlxdm.jjdjlxmc from T_WM_SJ_MYFSZZ  t,td_district quydm,td_time sjdm,td_economic_type jjdjlxdm,td_trade_mode dwmymyfsdm where sjdm.sjdm=t.sjdm and quydm.quydm=t.quydm and t.jjdjlxdm=jjdjlxdm.jjdjlxdm and t.dwmymyfsdm=dwmymyfsdm.dwmymyfsdm



/
