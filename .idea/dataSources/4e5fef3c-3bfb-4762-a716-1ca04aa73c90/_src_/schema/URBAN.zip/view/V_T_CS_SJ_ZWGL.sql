CREATE VIEW V_T_CS_SJ_ZWGL AS select t."ZBDM",t."QUYDM",t."SJDM",t."BYZ",t."BNZ",t."SJLDBS",t."SJBB",t."GXSJ",quydm.quymc,sjdm.sjmc from T_CS_SJ_ZWGL t,td_time sjdm,td_district quydm where sjdm.sjdm=t.sjdm and quydm.quydm=t.quydm



/
