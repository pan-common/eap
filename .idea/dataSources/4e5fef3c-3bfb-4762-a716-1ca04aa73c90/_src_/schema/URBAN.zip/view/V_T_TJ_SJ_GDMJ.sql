CREATE VIEW V_T_TJ_SJ_GDMJ AS select t."ZBDM",t."QUYDM",t."SJDM",t."BNZ",t."BZ",t."SJBB",t."GXSJ",quydm.quymc,sjdm.sjmc from T_TJ_SJ_GDMJ t,td_time sjdm,td_district quydm where sjdm.sjdm=t.sjdm and quydm.quydm=t.quydm



/
