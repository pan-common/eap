CREATE VIEW V_T_TJ_SJ_ZCF_GDP AS select t."ZBDM",t."SJDM",t."BNZ",t."SJBB",t."GXSJ",t."QUYDM",sjdm.sjmc,quydm.quymc from t_tj_sj_zcf_gdp t,td_time sjdm,td_district quydm where sjdm.sjdm=t.sjdm and quydm.quydm=t.quydm



/
