CREATE VIEW V_TD_INDEX1 AS select a."ZBDM",a."ZBZTDM",a."ZBFLDM",a."ZBMC",a."JLDW",a."ZBSM",a."SJK",a."SJB",a."SJBHZ_N",a."SJBHZ_J",a."SJBHZ_Y",a."KSSJ",a."ZZSJ",a."ZBMJ",a."SJV",a."SJLY",c.sjlymc,d.zbztmc,b.zbflmc,b.zbsjdm from td_index a,td_index_class b,td_datafrom c,td_index_stae d where a.zbfldm=b.zbfldm and a.sjly=c.sjly and a.zbztdm=d.zbztdm



/
