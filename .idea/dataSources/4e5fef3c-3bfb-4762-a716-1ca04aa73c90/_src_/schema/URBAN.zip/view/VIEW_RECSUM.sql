CREATE VIEW VIEW_RECSUM AS select a.sjid,a.ssbm,a.htmc,c.xmfzr,a.htje,nvl(b.AllNum,0) allnum,nvl(b.AllMoney,0) allmoney
from T_ZLGL_HTGL_JCXX A
left join
(SELECT HTID,COUNT(*) AllNum,sum(fpje) AllMoney
from T_ZLGL_FPYJ_RECORD
group by htid) B
on a.sjid=b.htid
left join
T_ZLGL_XMGL_JCXX C
on a.xmid=c.sjid


/
