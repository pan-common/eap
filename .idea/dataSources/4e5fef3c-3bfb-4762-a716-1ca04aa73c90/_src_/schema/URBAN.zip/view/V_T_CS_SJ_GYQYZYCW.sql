CREATE VIEW V_T_CS_SJ_GYQYZYCW AS select t."ZBDM",t."QUYDM",t."SJDM",t."BYZ",t."SJBB",t."GXSJ",quydm.quymc,sjdm.sjmc from T_CS_SJ_GYQYZYCW t,td_time sjdm,td_district quydm where sjdm.sjdm=t.sjdm and quydm.quydm=t.quydm



/
