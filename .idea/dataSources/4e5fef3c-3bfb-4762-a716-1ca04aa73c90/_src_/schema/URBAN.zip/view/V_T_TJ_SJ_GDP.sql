CREATE VIEW V_T_TJ_SJ_GDP AS select a."ZBDM",a."SJDM",a."QUYDM",a."HYFLDM",a."BNZ",a."BJZ",a."ZSSN",a."ZS1978",a."SJLDBS",a."SJBB",a."GXSJ",b.zbmc,c.sjmc,d.quymc,e.hyflmc from T_TJ_SJ_GDP a ,TD_INDEX b,TD_TIME c,td_district d,td_industry_yyyyyyymmmmdd e where a.zbdm=b.zbdm and a.sjdm=c.sjdm and a.quydm=d.quydm and a.hyfldm=e.hyfldm



/
