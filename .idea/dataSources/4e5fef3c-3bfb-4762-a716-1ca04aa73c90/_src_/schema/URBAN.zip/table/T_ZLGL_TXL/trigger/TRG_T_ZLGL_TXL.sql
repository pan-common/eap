CREATE TRIGGER TRG_T_ZLGL_TXL
BEFORE INSERT
  ON T_ZLGL_TXL
FOR EACH ROW
  begin
    select Txl_id.nextval into:new.TID from dual;
end;
/
