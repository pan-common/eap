CREATE TRIGGER TRG_T_ZLGL_RYGL_EXPERT
BEFORE INSERT
  ON T_ZLGL_RYGL_EXPERT
FOR EACH ROW
  begin
    select Expert_id.nextval into:new.EID from dual;
end;
/
