CREATE PACKAGE         "FGW_ASYNTEST$RP" as
  column_changed$$ RAW(1000);
  procedure rep_delete(
    "A1_o" IN NUMBER,
    "B2_o" IN VARCHAR2,
    site_name IN VARCHAR2,
    propagation_flag IN CHAR);
  procedure rep_delete(
    column_changed$ IN RAW,
    "A1_o" IN NUMBER,
    "B2_o" IN VARCHAR2,
    site_name IN VARCHAR2,
    propagation_flag IN CHAR);
  procedure rep_insert(
    "A1_n" IN NUMBER,
    "B2_n" IN VARCHAR2,
    site_name IN VARCHAR2,
    propagation_flag IN CHAR);
  procedure rep_update(
    "A1_o" IN NUMBER,
    "A1_n" IN NUMBER,
    "B2_o" IN VARCHAR2,
    "B2_n" IN VARCHAR2,
    site_name IN VARCHAR2,
    propagation_flag IN CHAR);
  procedure rep_update(
    column_changed$ IN RAW,
    "A1_o" IN NUMBER,
    "A1_n" IN NUMBER,
    "B2_o" IN VARCHAR2,
    "B2_n" IN VARCHAR2,
    site_name IN VARCHAR2,
    propagation_flag IN CHAR);
end "FGW_ASYNTEST$RP";



/
