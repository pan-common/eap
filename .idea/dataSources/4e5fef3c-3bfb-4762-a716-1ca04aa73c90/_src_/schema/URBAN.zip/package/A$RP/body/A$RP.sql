CREATE PACKAGE BODY         "A$RP" as
  procedure rep_delete(
    "A1_o" IN VARCHAR2,
    site_name IN VARCHAR2,
    propagation_flag IN CHAR) is
  begin
    rep_delete(
      NULL,
      "A1_o",
      site_name,
      propagation_flag);
  end rep_delete;
  procedure rep_delete(
    column_changed$ IN RAW,
    "A1_o" IN VARCHAR2,
    site_name IN VARCHAR2,
    propagation_flag IN CHAR) is
  begin
    DBMS_REPCAT_INTERNAL_PACKAGE.CALL(
      'STAT','A','REP_DELETE',4);
    DBMS_REPCAT_INTERNAL_PACKAGE.RAW_ARG(column_changed$);
    DBMS_REPCAT_INTERNAL_PACKAGE.VARCHAR2_ARG("A1_o");
    DBMS_REPCAT_INTERNAL_PACKAGE.VARCHAR2_ARG(site_name);
    DBMS_REPCAT_INTERNAL_PACKAGE.CHAR_ARG(propagation_flag);
  end rep_delete;
  procedure rep_insert(
    "A1_n" IN VARCHAR2,
    site_name IN VARCHAR2,
    propagation_flag IN CHAR) is
  begin
    DBMS_REPCAT_INTERNAL_PACKAGE.CALL(
      'STAT','A','REP_INSERT',3);
    DBMS_REPCAT_INTERNAL_PACKAGE.VARCHAR2_ARG("A1_n");
    DBMS_REPCAT_INTERNAL_PACKAGE.VARCHAR2_ARG(site_name);
    DBMS_REPCAT_INTERNAL_PACKAGE.CHAR_ARG(propagation_flag);
  end rep_insert;
  procedure rep_update(
    "A1_o" IN VARCHAR2,
    "A1_n" IN VARCHAR2,
    site_name IN VARCHAR2,
    propagation_flag IN CHAR) is
  begin
    rep_update(
      NULL,
      "A1_o",
      "A1_n",
      site_name,
      propagation_flag);
  end rep_update;
  procedure rep_update(
    column_changed$ IN RAW,
    "A1_o" IN VARCHAR2,
    "A1_n" IN VARCHAR2,
    site_name IN VARCHAR2,
    propagation_flag IN CHAR) is
  begin
    DBMS_REPCAT_INTERNAL_PACKAGE.CALL(
      'STAT','A','REP_UPDATE',5);
    DBMS_REPCAT_INTERNAL_PACKAGE.RAW_ARG(column_changed$);
    DBMS_REPCAT_INTERNAL_PACKAGE.VARCHAR2_ARG("A1_o");
    DBMS_REPCAT_INTERNAL_PACKAGE.VARCHAR2_ARG("A1_n");
    DBMS_REPCAT_INTERNAL_PACKAGE.VARCHAR2_ARG(site_name);
    DBMS_REPCAT_INTERNAL_PACKAGE.CHAR_ARG(propagation_flag);
  end rep_update;
end "A$RP";
/
