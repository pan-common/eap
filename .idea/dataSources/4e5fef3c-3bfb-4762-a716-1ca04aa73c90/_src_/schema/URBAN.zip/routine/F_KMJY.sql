CREATE function F_KMJY(P_ZBID in VARCHAR2, P_JFLB in VARCHAR2) return number is  ---科目结余
  FunctionResult number;
  Income         number;
  Expend         number;
begin
  --拨入金额
  select nvl(sum(brje), 0)
    into Income
    from t_zlgl_jfgl_jfbr
   where jfkm2 = P_JFLB and zbid=P_ZBID;
  --支出金额：核定金额+2级外拨金额
  select nvl(sum(hdje), 0) + nvl(sum(wbje), 0)
    into Expend
    from t_zlgl_jfgl_jfzc
   where jfkm2 = P_JFLB and zbid=P_ZBID;
   --剩余金额
   FunctionResult:=Income-Expend;
  return(FunctionResult);
end F_KMJY;


/
