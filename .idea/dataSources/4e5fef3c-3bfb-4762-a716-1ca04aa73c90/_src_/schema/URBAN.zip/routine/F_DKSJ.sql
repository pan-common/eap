CREATE function F_DKSJ(P_ZBID in VARCHAR2,P_CS IN INTEGER) return varchar2 is   ----到款时间
  FunctionResult varchar2(20);
begin
  select brsj
    into FunctionResult
    from(
    SELECT rownum RN,t.*
    from(
    select brsj,djsj,nvl(sum(brje),0) brje
    from  t_zlgl_jfgl_jfbr
    where zbid=P_ZBID
    group by brsj,djsj
    order by brsj,djsj asc) t)
   where RN=P_CS ;
  return(FunctionResult);
end F_DKSJ;


/
