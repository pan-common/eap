CREATE FUNCTION         "CHECK_UNIFORMITY" (
source_table varchar2,
target_table varchar2,
db_link varchar2) 
return number
as 
Scount number(2); 
Dcount number(10);
t_table varchar2(50);       
v_cursor number;    
source_table1 varchar2(50)  ;  
target_table1 varchar2(50)  ;
begin
t_table:=target_table||'@'||db_link ;     
source_table1:=upper(source_table);        --大写
 target_table1:=  upper(target_table);
--先检查结构  
v_cursor:=dbms_SQL.open_cursor;
dbms_SQL.parse(v_cursor,'select count(*) from (select column_name,data_type,data_length,nullable,data_precision from  user_tab_columns where table_name like :m1
minus 
select column_name,data_type,data_length,nullable,data_precision from  user_tab_columns@'||db_link||' where table_name like :m2)',dbms_SQL.v7);
dbms_SQL.BIND_VARIABLE(v_cursor,':m1',source_table1);
dbms_SQL.BIND_VARIABLE(v_cursor,':m2',target_table1);
dbms_SQL.define_column(v_cursor,1,Scount);  
dbms_sQL.close_cursor(v_cursor);
if Scount=0 then
--如果结构一致再检查内容，如果结构不一致，认为内容不一致
	v_cursor:=dbms_SQL.open_cursor;
	dbms_SQL.parse(v_cursor,'select count(*) from (
	select * from '||source_table||'
	minus 
	select * from '||t_table||'
	)',dbms_SQL.v7);
	dbms_SQL.define_column(v_cursor,1,Dcount);
	dbms_sQL.close_cursor(v_cursor);
end if;      
if Scount>0 then
return 1;
else        
	if dcount>0 then
		return 2;
	end if;
end if;
return 0;
commit;
end  check_Uniformity;



/
