CREATE PROCEDURE         "DEL_RPG" (          
rep_name varchar2
) as 
begin
commit;
end del_rpg;



/
