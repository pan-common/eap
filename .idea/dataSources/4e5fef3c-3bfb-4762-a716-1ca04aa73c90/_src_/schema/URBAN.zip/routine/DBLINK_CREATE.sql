CREATE PROCEDURE         "DBLINK_CREATE" (
host  varchar2,
name varchar2,
sid varchar2,
port varchar2) as   
v_cursor number;
v_create varchar2(500); 
     
/*
建立数据库连接
*/
begin           
	v_cursor:=DBMS_SQL.OPEN_CURSOR;               
	----这是一个私有连接
	v_create:='CREATE DATABASE LINK "'||name||'" connect to stat identified by stat USING ''(DESCRIPTION = (ADDRESS_LIST = (ADDRESS= (PROTOCOL = TCP)(Host = '||host||')(Port = '||port||')))(CONNECT_DATA =(SID = '||upper(sid)||')(SERVER = DEDICATED)))''';   
	begin     
	DBMS_SQL.Parse(v_cursor,v_create,DBMS_SQL.v7);   
	exception      
	 when others then    
	 /*有重名*/     
	 DBMS_OUTPUT.put_line(v_create);
	 goto countinue ;
	end;        
	<<countinue>>       
	DBMS_SQL.CLOSE_CURSOR(v_cursor);
end DBLink_Create;



/
