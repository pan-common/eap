CREATE PROCEDURE         "TRUNCATE_TABLE" (
table_name varchar2) as 
sqlstr  varchar2(400);
begin
sqlstr:='truncate table '||table_name;
execute_command(sqlstr);
end;



/
