CREATE function F_ZCZJ(P_ZBID in VARCHAR2) return number is   ----支出总计
  FunctionResult number;
begin
  --支出金额：核定金额+1级外拨金额+2级外拨金额
  select nvl(sum(hdje), 0) + nvl(sum(wbje), 0)
    into FunctionResult
    from t_zlgl_jfgl_jfzc
   where zbid=P_ZBID;
  return(FunctionResult);
end F_ZCZJ;


/
