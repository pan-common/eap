CREATE FUNCTION         "UNIQUE_GNAME" (
db_name varchar2
) return number   as 
v_gname varchar2(50);    
v_count number(1);
cursor c_gname is
select gname from dba_repgroup where gname like upper('%'||db_name||'%');
begin
	for v_count in 1..9 loop
   		open c_gname; 
   		loop
	   		fetch c_gname into v_gname;
	   		exit when c_gname%NOTFOUND;
	        if upper(db_name||'_asynchronous_grp_'||to_char(v_count)) = v_gname then
	        	goto n;
	        end if; 
        end loop;  
            return  v_count;
        exit;
        <<n>>
   		close c_gname;
   end loop;
    raise_application_error(-20001,'extra count 10');
commit;
end;




/
