CREATE function F_DKJE(P_ZBID in VARCHAR2,P_CS IN INTEGER) return number is   ----到款金额
  FunctionResult number;
begin
  select brje
    into FunctionResult
    from(
    SELECT rownum RN,t.*
    from(
    select brsj,djsj,nvl(sum(brje),0) brje
    from  t_zlgl_jfgl_jfbr
    where zbid=P_ZBID
    group by brsj,djsj
    order by brsj,djsj asc) t)
   where RN=P_CS ;
  return(FunctionResult);
end F_DKJE;


/
