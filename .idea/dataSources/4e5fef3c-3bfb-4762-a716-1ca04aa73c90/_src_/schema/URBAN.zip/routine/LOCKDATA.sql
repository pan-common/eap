CREATE procedure lockdata(lockstate out char) is
       v_sql varchar2(1000);
begin
       v_sql :=  'update T_HB_ZFJC_JCQK set rock=''1'' where SGJCJG is null  and jcrq < to_char(sysdate,''yyyy-mm-dd'')';
       execute immediate v_sql ;
      commit;
end lockdata;
/
