CREATE PROCEDURE         "EXECUTE_COMMAND" (
command varchar2
)as
v_cursor number;
begin                 
v_cursor:=DBMS_SQL.OPEN_CURSOR;              
DBMS_SQL.Parse(v_cursor,command,DBMS_SQL.v7);   
DBMS_SQL.CLOSE_CURSOR(v_cursor);
end       execute_command;



/
