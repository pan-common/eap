CREATE function F_WBJE(P_ZBID in VARCHAR2,P_WBLX IN VARCHAR2) return number is   ---外拨金额
  FunctionResult number;
begin
  select nvl(sum(wbje), 0)
    into FunctionResult
    from t_zlgl_jfgl_jfzc
   where zbid=P_ZBID AND WBLX=P_WBLX;
  return(FunctionResult);
end F_WBJE;


/
