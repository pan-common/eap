CREATE VIEW v_todowork_query AS
  SELECT
    `a`.`id`            AS `id`,
    `a`.`title`         AS `title`,
    `a`.`content`       AS `content`,
    `a`.`type`          AS `type`,
    `a`.`type_desc`     AS `type_desc`,
    `a`.`init_user`     AS `init_user`,
    `a`.`init_time`     AS `init_time`,
    `a`.`executor_user` AS `executor_user`,
    `a`.`executor_time` AS `executor_time`,
    `a`.`end_type`      AS `end_type`,
    `a`.`end_type_desc` AS `end_type_desc`,
    `a`.`end_time`      AS `end_time`,
    `a`.`jump_page`     AS `jump_page`,
    `a`.`param`         AS `param`,
    `a`.`is_read`       AS `is_read`,
    `a`.`note`          AS `note`,
    `a`.`update_time`   AS `update_time`,
    `b`.`user_id`       AS `user_id`,
    `c`.`law_case_id`   AS `law_case_id`
  FROM ((`court`.`t_common_todowork_user` `b` LEFT JOIN `court`.`t_common_todowork` `a`
      ON ((`a`.`id` = `b`.`todowork_id`))) LEFT JOIN `court`.`t_common_todowork_lawcase` `c`
      ON ((`a`.`id` = `c`.`todowork_id`)));
