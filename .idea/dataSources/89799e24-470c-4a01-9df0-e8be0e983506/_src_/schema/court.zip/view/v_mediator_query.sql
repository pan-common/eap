CREATE VIEW v_mediator_query AS
  SELECT
    `a`.`USER_ID`          AS `USER_ID`,
    `a`.`COURT_CODE`       AS `COURT_CODE`,
    `a`.`MEDIATOR_ORG_ID`  AS `MEDIATOR_ORG_ID`,
    `a`.`FULL_NAME`        AS `FULL_NAME`,
    `a`.`GENDER`           AS `GENDER`,
    (CASE WHEN (`a`.`GENDER` = '1')
      THEN '男'
     WHEN (`a`.`GENDER` = '2')
       THEN '女' END)       AS `GENDER_DESC`,
    `a`.`BIRTHDATE`        AS `BIRTHDATE`,
    `a`.`ETHNIC`           AS `ETHNIC`,
    `a`.`ID_TYPE_CODE`     AS `ID_TYPE_CODE`,
    `a`.`ID_TYPE_DESC`     AS `ID_TYPE_DESC`,
    `a`.`ID_NUMBER`        AS `ID_NUMBER`,
    `a`.`TELEPHONE`        AS `TELEPHONE`,
    `a`.`GOODAT`           AS `GOODAT`,
    `a`.`EMAIL`            AS `EMAIL`,
    `a`.`PHOTO`            AS `PHOTO`,
    `a`.`POLITICAL_STATUS` AS `POLITICAL_STATUS`,
    `a`.`DUTY`             AS `DUTY`,
    `a`.`Company`          AS `Company`,
    `a`.`position`         AS `position`
  FROM `court`.`t_jftj_mediator` `a`;
