CREATE VIEW v_natural_person_only AS
  SELECT
    `court`.`t_common_natural_person`.`USERID`    AS `USERID`,
    `court`.`t_common_natural_person`.`FULL_NAME` AS `FULL_NAME`
  FROM `court`.`t_common_natural_person`
  GROUP BY `court`.`t_common_natural_person`.`USERID`;
