CREATE VIEW v_videoconf_query AS
  SELECT
    `a`.`videoconfid`        AS `videoconfid`,
    `a`.`subject`            AS `subject`,
    `a`.`orgid`              AS `orgid`,
    `a`.`chair_Passwd`       AS `chair_Passwd`,
    `a`.`participant_passwd` AS `participant_passwd`,
    `a`.`starttime`          AS `starttime`,
    `a`.`endtime`            AS `endtime`,
    `a`.`max_participant`    AS `max_participant`,
    `a`.`conf_type`          AS `conf_type`,
    `a`.`particpant_limited` AS `particpant_limited`,
    `a`.`groupId`            AS `groupId`,
    `a`.`createTime`         AS `createTime`,
    `a`.`createUser`         AS `createUser`,
    `a`.`vaild`              AS `vaild`,
    `a`.`law_case_id`        AS `law_case_id`,
    `b`.`user_id`            AS `user_id`,
    `b`.`user_role_code`     AS `user_role_code`,
    `b`.`user_role_desc`     AS `user_role_desc`,
    `c`.`fullName`           AS `fullName`,
    `d`.`GEFORE_NO`          AS `GEFORE_NO`
  FROM (((`court`.`t_videoconf_info` `a` LEFT JOIN `court`.`t_videoconf_user` `b`
      ON ((`a`.`videoconfid` = `b`.`videoconfid`))) LEFT JOIN `court`.`v_user_query` `c`
      ON ((`b`.`user_id` = `c`.`user_id`))) LEFT JOIN `court`.`t_common_law_case` `d`
      ON ((`a`.`law_case_id` = `d`.`LAW_CASE_ID`)));
