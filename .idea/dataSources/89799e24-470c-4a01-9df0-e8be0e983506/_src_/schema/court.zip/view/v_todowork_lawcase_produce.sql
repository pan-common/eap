CREATE VIEW v_todowork_lawcase_produce AS
  SELECT
    `a`.`keystone`           AS `produce_id`,
    `a`.`value`              AS `produce_name`,
    `a`.`parent_id`          AS `parent_id`,
    `a`.`indexno`            AS `indexno`,
    `c`.`todowork_type_id`   AS `todowork_type_id`,
    `c`.`todowork_type_desc` AS `todowork_type_desc`,
    `c`.`todowork_title`     AS `todowork_title`,
    `c`.`todowork_content`   AS `todowork_content`,
    `c`.`sms_content`        AS `sms_content`,
    `c`.`sms_contentb`       AS `sms_contentb`,
    `c`.`sms_contenttjy`     AS `sms_contenttjy`,
    `c`.`email_content`      AS `email_content`,
    `c`.`is_send_sms`        AS `is_send_sms`,
    `c`.`is_send_email`      AS `is_send_email`,
    `c`.`update_time`        AS `update_time`,
    `c`.`valid`              AS `valid`
  FROM ((`court`.`all_dictionary` `a` LEFT JOIN `court`.`t_common_todoworktype_lawcase` `b`
      ON ((`a`.`keystone` = `b`.`law_case_produce_id`))) LEFT JOIN `court`.`t_common_todowork_type` `c`
      ON ((`b`.`todowork_type_id` = `c`.`todowork_type_id`)))
  WHERE (`a`.`parent_id` = 'BUSINESS_SETTING_CASE_STATUS');
