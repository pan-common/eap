CREATE VIEW v_case_material_query AS
  SELECT
    `a`.`id`                            AS `id`,
    `a`.`required`                      AS `required`,
    `a`.`indexno`                       AS `indexno`,
    `b`.`CASE_ID`                       AS `CASE_ID`,
    `b`.`CASE_CONTENT`                  AS `CASE_CONTENT`,
    `a`.`LITIGATION_MATERIALS_ID`       AS `MATERIALS_ID`,
    `c`.`LITIGATION_MATERIALS_NAME`     AS `MATERIALS_NAME`,
    `c`.`LITIGATION_MATERIALS_POSITION` AS `defmust`,
    `c`.`file_format`                   AS `file_format`
  FROM ((`court`.`t_lawcouse_litigationmaterials` `a` LEFT JOIN `court`.`t_common_case` `b`
      ON ((`a`.`LAW_CASE_COUSE_ID` = `b`.`CASE_ID`))) LEFT JOIN `court`.`t_litigation_materials` `c`
      ON ((`a`.`LITIGATION_MATERIALS_ID` = `c`.`ID`)));
