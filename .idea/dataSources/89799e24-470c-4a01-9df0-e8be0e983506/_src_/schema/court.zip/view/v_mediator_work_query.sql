CREATE VIEW v_mediator_work_query AS
  SELECT
    `a`.`UPDATE_TIME`     AS `UPDATE_TIME`,
    `a`.`LAW_CASE_ID`     AS `LAW_CASE_ID`,
    `a`.`QS_CASE_DESC`    AS `QS_CASE_DESC`,
    `b`.`USER_ID`         AS `USER_ID`,
    `b`.`FULL_NAME`       AS `FULL_NAME`,
    `c`.`LAW_CASE_RESULT` AS `LAW_CASE_RESULT`,
    `b`.`COURT_CODE`      AS `COURT_CODE`
  FROM ((`court`.`t_jftj_mediator` `b` LEFT JOIN `court`.`t_common_law_case` `a`
      ON ((`a`.`CONCILIATOR_ID` = `b`.`USER_ID`))) LEFT JOIN `court`.`t_common_law_case_result` `c`
      ON ((`a`.`LAW_CASE_ID` = `c`.`LAW_CASE_ID`)));
