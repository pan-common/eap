CREATE VIEW v_fjfl_lawcase_score AS
  SELECT
    sum(`court`.`t_fjfl_result`.`score`)  AS `score`,
    `court`.`t_fjfl_result`.`law_case_id` AS `law_case_id`
  FROM `court`.`t_fjfl_result`
  GROUP BY `court`.`t_fjfl_result`.`law_case_id`;
