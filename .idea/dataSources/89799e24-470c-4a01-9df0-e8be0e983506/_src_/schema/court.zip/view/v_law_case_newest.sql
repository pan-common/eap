CREATE VIEW v_law_case_newest AS
  SELECT
    `a`.`LAW_CASE_PROCEDUCE_ID`   AS `LAW_CASE_PROCEDUCE_ID`,
    `a`.`LAW_CASE_ID`             AS `LAW_CASE_ID`,
    `a`.`OPERATION_ID`            AS `OPERATION_ID`,
    `a`.`LAW_CASE_PROCEDUCE`      AS `LAW_CASE_PROCEDUCE`,
    `a`.`LAW_CASE_PROCEDUCE_DESC` AS `LAW_CASE_PROCEDUCE_DESC`,
    `a`.`LAW_CASE_PROCEDUCE_TEXT` AS `LAW_CASE_PROCEDUCE_TEXT`,
    `a`.`UPDATE_TIME`             AS `UPDATE_TIME`,
    `a`.`BZ`                      AS `BZ`,
    `a`.`VALID`                   AS `VALID`
  FROM (`court`.`v_law_case_produce_desc` `b` LEFT JOIN `court`.`t_common_law_case_produce` `a`
      ON (((`a`.`LAW_CASE_ID` = `b`.`LAW_CASE_ID`) AND (`a`.`UPDATE_TIME` = `b`.`CT`))));
