CREATE VIEW v_officer_role AS
  SELECT
    `court`.`base_user`.`user_id`                 AS `user_id`,
    `court`.`base_user`.`user_code`               AS `user_code`,
    `court`.`t_qx_user_role`.`ROLE_ID`            AS `ROLE_ID`,
    `court`.`t_common_court_officer`.`FULL_NAME`  AS `FULL_NAME`,
    `court`.`t_common_court_officer`.`COURT_CODE` AS `COURT_CODE`
  FROM ((`court`.`t_common_court_officer`
    JOIN `court`.`base_user` ON ((`court`.`base_user`.`user_id` = `court`.`t_common_court_officer`.`USER_ID`))) JOIN
    `court`.`t_qx_user_role` ON ((`court`.`t_qx_user_role`.`USER_ID` = `court`.`t_common_court_officer`.`USER_ID`)));
