CREATE VIEW v_dic_dsrlx AS
  SELECT
    `court`.`all_dictionary`.`keystone`  AS `keystone`,
    `court`.`all_dictionary`.`value`     AS `value`,
    `court`.`all_dictionary`.`param1`    AS `param1`,
    `court`.`all_dictionary`.`param2`    AS `param2`,
    `court`.`all_dictionary`.`param3`    AS `param3`,
    `court`.`all_dictionary`.`param4`    AS `param4`,
    `court`.`all_dictionary`.`param5`    AS `param5`,
    `court`.`all_dictionary`.`param6`    AS `param6`,
    `court`.`all_dictionary`.`param7`    AS `param7`,
    `court`.`all_dictionary`.`parent_id` AS `parent_id`,
    `court`.`all_dictionary`.`indexno`   AS `indexno`
  FROM `court`.`all_dictionary`
  WHERE (`court`.`all_dictionary`.`parent_id` = 'zdlbSP55')
  ORDER BY `court`.`all_dictionary`.`indexno`;
