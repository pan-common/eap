CREATE VIEW v_law_case_produce_desc AS
  SELECT
    `court`.`t_common_law_case_produce`.`LAW_CASE_ID`      AS `LAW_CASE_ID`,
    max(`court`.`t_common_law_case_produce`.`UPDATE_TIME`) AS `CT`
  FROM `court`.`t_common_law_case_produce`
  GROUP BY `court`.`t_common_law_case_produce`.`LAW_CASE_ID`;
