CREATE VIEW v_user_query AS
  SELECT
    `a`.`user_id`        AS `user_id`,
    `a`.`user_type`      AS `user_type`,
    `a`.`user_type_desc` AS `user_type_desc`,
    `a`.`telephone`      AS `telephone`,
    `a`.`user_code`      AS `user_code`,
    `a`.`password`       AS `password`,
    `a`.`CREATE_TIME`    AS `CREATE_TIME`,
    `a`.`UPDATE_TIME`    AS `UPDATE_TIME`,
    `a`.`NOTE`           AS `NOTE`,
    `a`.`valid`          AS `valid`,
    `a`.`COURT_CODE`     AS `COURT_CODE`,
    `b`.`party_name`     AS `fullName`,
    `d`.`ORGAN_NAME`     AS `ORGAN_NAME`
  FROM (((`court`.`base_user` `a` LEFT JOIN `court`.`v_user_name` `b` ON ((`a`.`user_id` = `b`.`user_id`))) LEFT JOIN
    `court`.`t_qx_user_organ` `c` ON ((`a`.`user_id` = `c`.`USER_ID`))) LEFT JOIN `court`.`t_qx_organ` `d`
      ON ((`c`.`ORGAN_ID` = `d`.`ORGAN_ID`)))
  WHERE (`a`.`valid` = '1');
