CREATE VIEW v_party_query AS
  SELECT
    `a`.`PARTY_ID`                     AS `PARTY_ID`,
    `a`.`LAW_CASE_ID`                  AS `LAW_CASE_ID`,
    `a`.`PARTY_TYPE`                   AS `PARTY_TYPE`,
    `a`.`USE_CODE`                     AS `USE_CODE`,
    `a`.`PARTY_CASE_TYPE`              AS `PARTY_CASE_TYPE`,
    `a`.`AGENT_TYPE`                   AS `AGENT_TYPE`,
    `a`.`DEFENDER_TYPE`                AS `DEFENDER_TYPE`,
    `a`.`PARTY_POSITION`               AS `PARTY_POSITION`,
    `a`.`THIRD_PARTY_TYPE`             AS `THIRD_PARTY_TYPE`,
    `a`.`UPDATEDATE`                   AS `UPDATEDATE`,
    `a`.`VALID`                        AS `VALID`,
    (CASE WHEN (`a`.`PARTY_TYPE` = '1')
      THEN `b`.`FULL_NAME`
     ELSE `c`.`UNIT_NAME` END)         AS `PARTY_NAME`,
    `f`.`value`                        AS `PARTY_TYPE_DESC`,
    `e`.`value`                        AS `PARTY_POSITION_DESC`,
    (CASE WHEN ((`d`.`CLOSE_CASE_MODE` IS NOT NULL) OR (`d`.`CLOSE_CAUSE` IS NOT NULL))
      THEN '进行中'
     ELSE '已结案' END)                   AS `IS_HAVE_CASE`,
    `b`.`GENDER`                       AS `GENDER`,
    (CASE WHEN (`b`.`GENDER` = '1')
      THEN '男'
     WHEN (`b`.`GENDER` = '2')
       THEN '女' END)                   AS `gender_Desc`,
    `b`.`AGE`                          AS `AGE`,
    `b`.`COUNTRY`                      AS `COUNTRY`,
    `b`.`ETHNIC`                       AS `ETHNIC`,
    `b`.`BIRTHDATE`                    AS `BIRTHDATE`,
    `b`.`LITERACY`                     AS `LITERACY`,
    (CASE WHEN (`a`.`PARTY_TYPE` = '1')
      THEN `b`.`PERADDRESS`
     ELSE `c`.`ADDRESS` END)           AS `ADDRESS`,
    `b`.`POLITICAL_STATUS`             AS `POLITICAL_STATUS`,
    `b`.`STATUE`                       AS `STATUE`,
    (CASE WHEN (`a`.`PARTY_TYPE` = '1')
      THEN `b`.`ID_TYPE_CODE`
     ELSE `c`.`LICENSE_TYPE_CODE` END) AS `ID_TYPE_CODE`,
    (CASE WHEN (`a`.`PARTY_TYPE` = '1')
      THEN `b`.`ID_TYPE_DESC`
     ELSE `c`.`LICENSE_TYPE_DESC` END) AS `ID_TYPE_DESC`,
    (CASE WHEN (`a`.`PARTY_TYPE` = '1')
      THEN `b`.`ID_NUMBER`
     ELSE `c`.`LICENSE_NUMBER` END)    AS `ID_NUMBER`,
    (CASE WHEN (`a`.`PARTY_TYPE` = '1')
      THEN `b`.`PERADDRESS`
     ELSE `c`.`MAIN_ADDRESS` END)      AS `PERADDRESS`,
    (CASE WHEN (`a`.`PARTY_TYPE` = '1')
      THEN `b`.`ADDRESS`
     ELSE `c`.`ADDRESS` END)           AS `REG_ADDRESS`,
    (CASE WHEN (`a`.`PARTY_TYPE` = '1')
      THEN `b`.`SENDADDRESS`
     ELSE `c`.`SENDADDRESS` END)       AS `SENDADDRESS`,
    `c`.`LICENSE_NUMBER`               AS `LICENSE_NUMBER`,
    `c`.`UNIT_TYPE_CODE`               AS `UNIT_TYPE_CODE`,
    `c`.`UNIT_TYPE_DESC`               AS `UNIT_TYPE_DESC`,
    `c`.`LEGAL_NAME`                   AS `LEGAL_NAME`,
    (CASE WHEN (`a`.`PARTY_TYPE` = '1')
      THEN `b`.`PHONE_NUMBER`
     ELSE `c`.`LEGAL_PHONE` END)       AS `PHONE_NUMBER`,
    `c`.`LEGAL_CARD_TYPE`              AS `LEGAL_CARD_TYPE`,
    `c`.`LEGAL_CARD_TYPE_DESC`         AS `LEGAL_CARD_TYPE_DESC`,
    `c`.`LEGAL_CARD_NUMBER`            AS `LEGAL_CARD_NUMBER`,
    `d`.`CASE_NO`                      AS `CASE_NO`,
    `d`.`GEFORE_NO`                    AS `GEFORE_NO`,
    `d`.`COURT`                        AS `COURT`
  FROM (((((`court`.`t_common_party` `a` LEFT JOIN `court`.`t_common_natural_person` `b`
      ON ((`a`.`PARTY_ID` = `b`.`PARTY_ID`))) LEFT JOIN `court`.`t_common_legal` `c`
      ON ((`a`.`PARTY_ID` = `c`.`PARTY_ID`))) LEFT JOIN `court`.`t_common_law_case` `d`
      ON ((`a`.`LAW_CASE_ID` = `d`.`LAW_CASE_ID`))) LEFT JOIN `court`.`v_dic_ssdw` `e`
      ON ((`a`.`PARTY_POSITION` = `e`.`keystone`))) LEFT JOIN `court`.`v_dic_dsrlx` `f`
      ON ((`a`.`PARTY_TYPE` = `f`.`keystone`)))
  WHERE (`d`.`VALID` <> '2');
