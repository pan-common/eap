CREATE VIEW v_user_name AS
  SELECT
    `a`.`user_id`                AS `user_id`,
    (CASE WHEN (`a`.`user_type` = '01')
      THEN `c`.`FULL_NAME`
     WHEN (`a`.`user_type` = '02')
       THEN `e`.`FULL_NAME`
     WHEN (`a`.`user_type` = '03')
       THEN `d`.`FULL_NAME`
     WHEN (`a`.`user_type` = '04')
       THEN `b`.`FULL_NAME` END) AS `party_name`
  FROM ((((`court`.`base_user` `a` LEFT JOIN `court`.`t_common_court_officer` `b`
      ON ((`a`.`user_id` = `b`.`USER_ID`))) LEFT JOIN `court`.`v_natural_person_only` `c`
      ON ((`a`.`user_id` = `c`.`USERID`))) LEFT JOIN `court`.`t_jftj_mediator` `d`
      ON ((`a`.`user_id` = `d`.`USER_ID`))) LEFT JOIN `court`.`t_common_lawyer` `e`
      ON ((`a`.`user_id` = `e`.`USERID`)));
