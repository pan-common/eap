CREATE VIEW v_qx_user AS
  SELECT
    `a`.`user_id`     AS `user_id`,
    `a`.`user_name`   AS `user_name`,
    `a`.`seq`         AS `seq`,
    `a`.`salt`        AS `salt`,
    `a`.`password`    AS `password`,
    `a`.`create_time` AS `create_time`,
    `a`.`update_time` AS `update_time`,
    `a`.`valid`       AS `valid`,
    `a`.`creater`     AS `creater`,
    `a`.`locked`      AS `locked`,
    `c`.`role_id`     AS `role_id`,
    `c`.`name`        AS `role_name`,
    `e`.`organ_id`    AS `organ_id`,
    `e`.`name`        AS `organ_name`
  FROM ((((`eap`.`t_qx_user` `a` LEFT JOIN `eap`.`t_qx_user_role` `b` ON ((`a`.`user_id` = `b`.`user_id`))) LEFT JOIN
    `eap`.`t_qx_role` `c` ON ((`b`.`role_id` = `c`.`role_id`))) LEFT JOIN `eap`.`t_qx_user_organ` `d`
      ON ((`a`.`user_id` = `d`.`user_id`))) LEFT JOIN `eap`.`t_qx_organ` `e` ON ((`d`.`organ_id` = `e`.`organ_id`)));
