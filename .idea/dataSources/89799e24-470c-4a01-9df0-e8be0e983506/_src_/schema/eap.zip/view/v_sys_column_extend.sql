CREATE VIEW v_sys_column_extend AS
  SELECT
    `a`.`TABLE_SCHEMA`     AS `table_schema`,
    `a`.`TABLE_NAME`       AS `table_name`,
    `a`.`COLUMN_NAME`      AS `column_name`,
    `a`.`ORDINAL_POSITION` AS `ordinal_position`,
    `a`.`IS_NULLABLE`      AS `is_nullable`,
    `a`.`DATA_TYPE`        AS `data_type`,
    `a`.`COLUMN_KEY`       AS `column_key`,
    `a`.`COLUMN_COMMENT`   AS `column_comment`,
    `b`.`id`               AS `id`,
    `b`.`seq`              AS `seq`,
    `b`.`form_show`        AS `form_show`,
    `b`.`list_show`        AS `list_show`,
    `b`.`width_per`        AS `width_per`,
    `b`.`input_type`       AS `Input_type`,
    `b`.`is_query`         AS `is_query`,
    `b`.`param`            AS `param`,
    `b`.`verify`           AS `verify`,
    `b`.`required`         AS `required`
  FROM (`eap`.`t_sys_column_extend` `b` LEFT JOIN `information_schema`.`columns` `a`
      ON (((`a`.`TABLE_SCHEMA` = `b`.`table_schema`) AND (`a`.`TABLE_NAME` = `b`.`table_name`) AND
           (`a`.`COLUMN_NAME` = `b`.`column_name`))));
